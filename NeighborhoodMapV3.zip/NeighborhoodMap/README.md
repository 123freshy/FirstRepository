## Description:

This project is a neighborhood map displaying golf courses in the Summerlin area (west side of Las Vegas, NV)

## Features:

Markers change color every time user hover over or click on marker. Markers will also bounce on selection from list menu and drop when clicked directly.

## API:

Google Map, Wikipedia, and New York Times.  
* New York Times (NYT) articles are not really relevant to the courses, but API was left there to as an exercise on linking APIs.  NYT doesnt use knockout.
* Not all courses have wikipedia articles related to them, however API is in place and uses knockout for linking
* Google Map API was used to display map, and info windows.

## Tools:

HTML, CSS, JavaScript, Knockout JS, AJAX, jQuery

## File Description:

* NeighborhoodMap.html: this is the HTML File.
* Mappingdisplay.js: JS file with the code for displaying map.
* script.js: JS file with the code for API linking.
* libs: Folder with KO and jQuery libraries.

## Resource(s):

1. Udacity Hello Map Quiz
2. Udacity Courses on knockoutjs, google API, asynchronous requests and AJAX.
3. KnockoutJS (http://knockoutjs.com/documentation/css-binding.html)
4. One on One sessions (2 of them)
