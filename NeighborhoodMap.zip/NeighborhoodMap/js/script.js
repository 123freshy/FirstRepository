
function loadData() {

    var $wikiElem = $('#wikipedia-links');
    var $nytHeaderElem = $('#nytimes-header');
    var $nytElem = $('#nytimes-articles');

    // clear out old data before new request
    $wikiElem.text("");
    $nytElem.text("");

    var cityStr = "Chicago";
    //code below for NYT

    var nytimesUrl = 'https://api.nytimes.com/svc/search/v2/articlesearch.json?q='+ cityStr + '&sort=newest&api-key=16c8d60e661445db9ea3e8fa996e35dc'
    $.getJSON(nytimesUrl, function(data) {  //the data object is the actual response from the NYT
      $nytHeaderElem.text('New York Times Articles About' + cityStr);
      articles = data.response.docs;
      for (var i= 0; i < articles.length; i++) {
        var article = articles [i];
        $nytElem.append ( '<li class = "article">' +
        '<a href="' + article.web_url +'">' +article.headline.main+'</a>' +
        '<p>' + article.snippet + '</p>' +
        '</li>');
      };
    })
      .error(function (e) {  //man, not even the error gives an error
        $nytHeaderElem.text('NYT articles cannot be loaaded');
      });

      //wikipedia-AJAX request
      var wikiUrl = 'http://en.wikipedia.org/w/api.php?action=opensearch&search=' + cityStr + '&format=json&callback=wikiCallback';

      var wikiRequestTimeout = setTimeout (function() {
      $wikiElem.text("failed to get wikipedia resources");
      }, 8000); //this didnt trigger

      $.ajax({
          url: wikiUrl,  //url parameter
          dataType: "jsonp",
          success: function(response) {
            var articleList = response[1];
            for (var i=0; i < articleList.length; i++) {
              articleStr = articleList[i];
              var url = 'http://en.wikipedia.org/wiki/'+ articleStr;
              $wikiElem.append('<li><a href="'+ url + '">'+
              articleStr + '</a></li>');
            };
            clearTimeout(wikiRequestTimeout); //clear timeout
          }
      });
  return false;

};



$('#form-container').submit(loadData);
