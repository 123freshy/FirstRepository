##Who doesn't like delicious pizza?

This site supports [this quiz](https://www.udacity.com/course/viewer#!/c-ud860/l-4147498575/e-4154208580/m-4142388616) from Udacity's [Browser Rendering Optimization](http://udacity.com/ud860)

This pizzeria site is a performance nightmare. Record a timeline trace and watch the Forced Synchronous Layout warnings pop up. Can you make this site run at 60fps?
# This is the Readme for the Pizzeria website
The site generates random pizzas with random ingredients, names, recipes.  The site also allows the user to move a slider to change the pizza size to either small, medium or large.
The site was originally functionable, but had a bunch of performance issues.  This readme will go into each part of the code and will explain what was done to improve performance for each portion where changes took place.

## Main Portion of the Code
* Pizza Generator
* Pizza re-sizer

## Pizza Generator
This portion of the code names the pizza;  pulls adjetives and nowns from an array.  Also selects random crusts, cheeses, meats, vegetables, etc.  Pretty much just does what it's name says.  It generates a friggin' pizza.
No changes were done to improve performance in this portion of the code.

## Pizza re-sizer
As it's name describes, it changes the size of the pizzas.  Its made up of the following:
* Change Slider Label
* Size Switcher

### Change Slider Label:
This is a slider that user can slide to change sizes to Small, Medium or Large.

### Size sizeSwitcher
Here the size of the pizza gets changes.  
There was a function that was causing Forced Synchronous Layout (FSL) along with other performance issues.  Here is what was completed to improve performance.
* Created  `var randomPizzas = document.getElementsByClassName("randomPizzaContainer");` to save multiple collection of DOM nodes into single variable.  This way code doesnt have to query the DOM every time.
* There was a `for`loop that accessess a geometric property in this case `offsetWidth` and then changes the styles.  Doing this causes FSL.
* Delete function `determineDx`  it was useless.
* Change code to use percent width instead of increaseing by a pixel value.
* New version of the `for` loop simplifies logic by figuring out what size the user needs and sets the width of every element to that percentage.  Also removes FSL.
* No more query selecting of DOM inside the loop.
* Added `var length = randomPizzas.length;` to eliminate querying of the random pizzas array.
* Changed `querySelectorAll` to `getElemetnsByClassName`.  Saw in documentation that this was much faster.
