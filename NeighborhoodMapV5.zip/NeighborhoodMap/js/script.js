
function loadData(cityStr) {

    var $wikiElem = $('#wikipedia-links');


    // clear out old data before new request
    $wikiElem.text("");


    //var cityStr = "Las Vegas";



      //wikipedia-AJAX request
      var wikiUrl = 'http://en.wikipedia.org/w/api.php?action=opensearch&search=' + cityStr + '&format=json&callback=wikiCallback';

      var wikiRequestTimeout = setTimeout (function() {
      $wikiElem.text("failed to get wikipedia resources");
      }, 8000); //this didnt trigger

      $.ajax({
          url: wikiUrl,  //url parameter
          dataType: "jsonp",
          success: function(response) {
            var articleList = response[1];
            for (var i=0; i < articleList.length; i++) {
              var wikiobject = {}; //need to define to later add
              wikiobject.wikitext = articleList[i];
              wikiobject.url = 'http://en.wikipedia.org/wiki/'+ articleList[i];
              viewmodel.wikilist.push(wikiobject);
            };
            clearTimeout(wikiRequestTimeout); //clear timeout
          }
      });
  return false;//not needed makes submit button that is no longer there refresh

};
